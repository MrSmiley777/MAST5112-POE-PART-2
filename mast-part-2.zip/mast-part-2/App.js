import React, { useState } from 'react';
import { View, Text, TextInput, Button, FlatList, StyleSheet, TouchableOpacity, Image } from 'react-native';

// Imported the Food.jpg in the assets to be used.
const foodImage = require('./assets/Food.jpg'); // Using the image bundled with the file so anybody can use the file. Require is the method that loads the image from the asset folder.

export default function App() {
  const [showMenu, setShowMenu] = useState(false); //This is to show the menu page, it is set as false as the welcome page is displayed first.
  const [dishName, setDishName] = useState('');
  const [description, setDescription] = useState('');
  const [course, setCourse] = useState('Starters'); //Default set to starter.
  const [price, setPrice] = useState('');
  const [menuItems, setMenuItems] = useState([]); //Menu items will be stored in this array
  const [showCourseOptions, setShowCourseOptions] = useState(false); //It is set as false as it used to say whether to show the drop down or not for the course types.

  const handleAddItem = () => { // A function called when user clicks the button.
    if (dishName && description && price) { //checks the fields are filled.
      const newItem = {
        id: Math.random().toString(), //Meant to assign a random number as an id for the dish added.
        dishName,
        description,
        course,
        price,
      };
      setMenuItems((currentItems) => [...currentItems, newItem]);
      setDishName('');
      setDescription('');
      setPrice('');
    } else {
      alert("Please fill in all fields"); //An error message pops up if all fields are not filled.
    }
  };

  if (!showMenu) { //If false this means we are on the welcome screen.
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Welcome to the Menu App</Text> 
        <Button title="Go to Menu" onPress={() => setShowMenu(true)} /> 
        <Image source={foodImage} style={styles.foodImage} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Add a Menu Item</Text>

      <TextInput
        style={styles.input}
        placeholder="Dish Name"
        value={dishName}
        onChangeText={setDishName}
      />
      
      <TextInput
        style={styles.input}
        placeholder="Description"
        value={description}
        onChangeText={setDescription}
      />

      <TouchableOpacity onPress={() => setShowCourseOptions(!showCourseOptions)}>
        <Text style={styles.input}>
          {course} (Tap to change)
        </Text>
      </TouchableOpacity>

      {showCourseOptions && ( 
        <View>
          <TouchableOpacity onPress={() => { setCourse('Starters'); setShowCourseOptions(false); }}>
            <Text style={styles.courseOption}>Starters</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => { setCourse('Mains'); setShowCourseOptions(false); }}>
            <Text style={styles.courseOption}>Mains</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => { setCourse('Dessert'); setShowCourseOptions(false); }}>
            <Text style={styles.courseOption}>Dessert</Text>
          </TouchableOpacity>
        </View>
      )}

      <TextInput
        style={styles.input}
        placeholder="Price"
        keyboardType="numeric" //Only numbers to be entered.
        value={price}
        onChangeText={setPrice}
      />
    
      <Button title="Add Item" onPress={handleAddItem} /> 
      <Text style={styles.menuTitle}>Menu Items:</Text>
      {menuItems.length > 0 ? ( //To check whether there are menu items.
        <FlatList
          data={menuItems} //array of menu items to be displayed
          keyExtractor={(item) => item.id} //unique key for each item
          renderItem={({ item }) => ( //function for displaying the menu items
            <View style={styles.menuItem}>
              <Text>{item.dishName}</Text>
              <Text>{item.description}</Text>
              <Text>{item.course}</Text>
              <Text>${item.price}</Text>
            </View>
          )}
        />
      ) : (
        <Text>No menu items added yet.</Text>
      )}
      <Text style={styles.totalItems}>Total Menu Items: {menuItems.length}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'flex-start',
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingLeft: 10,
    justifyContent: 'center',
    textAlignVertical: 'center',
  },
  menuTitle: {
    fontSize: 20,
    marginVertical: 20,
  },
  menuItem: {
    marginBottom: 10,
    padding: 10,
    borderColor: 'lightgray',
    borderWidth: 1,
    borderRadius: 5,
  },
  totalItems: {
    marginTop: 20,
    fontSize: 16,
    textAlign: 'center',
  },
  foodImage: {
    width: 345,   
    height: 670,  
    marginTop: 20,
    alignSelf: 'center',
  },
  courseOption: {
    fontSize: 18,
    padding: 10,
    backgroundColor: '#ddd',
    textAlign: 'center',
    marginVertical: 5,
    borderRadius: 5,
  },
});







